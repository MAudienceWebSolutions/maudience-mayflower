<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'mayflower');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'D )V%D&!^J~K+lp+4RlThPP-~~+(M!08<.VI3bunr.}8gSu 0LwrXTS}FDIU|Kn`');
define('SECURE_AUTH_KEY',  'baM`])y}uCd*`~_-9+E$v(-.^dH[H6AKqb46 &hA_<:NJP5.* +-N#a9iw|e+,19');
define('LOGGED_IN_KEY',    'hG+i#rm_Gd`;3;]Ue]Z+#UWL|5b0BXtKAz61*12a$I30JQmd6qjd77+f)b-cfB4j');
define('NONCE_KEY',        '&d>y[Tg7+Tr)P=60@O-3O&Z@[Rh3]|`G+.-+PJ(gF?x1+^WDoi~4*S^4d3~|~)vj');
define('AUTH_SALT',        '4uV&0r15<m%+rY^*OfU{I1rBF++S/oR|z&{&D~9G_wTD]yiB7ccXI_Pp)]Xr!ozT');
define('SECURE_AUTH_SALT', 'fTr~^FFg@J2?=2zp9]n J(eGK3hF&K0RIuf+Tu2X-+|-l<,?gBv$?iU|%3>wLAo0');
define('LOGGED_IN_SALT',   'W$mY.2Y_kASkC#=t=P}p*@Gn-nXsT1q?8d`N?pYk)e|`!hH?,aWVne;>5@ah}yJb');
define('NONCE_SALT',       'rn&{ E_ZJ}v*?kY+cUc2GC=ENdr~1_kzwJh0_oE r-uc2XMa.KogQ=q6peALS-5?');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'mfl_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
